﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.picBlinking = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblToppings = New System.Windows.Forms.Label()
        Me.Subtotal = New System.Windows.Forms.Label()
        Me.Tax = New System.Windows.Forms.Label()
        Me.Total = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btnTotal = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GrpBoxBurger = New System.Windows.Forms.GroupBox()
        Me.radBuffalo = New System.Windows.Forms.RadioButton()
        Me.radVeggie = New System.Windows.Forms.RadioButton()
        Me.radTurkey = New System.Windows.Forms.RadioButton()
        Me.radBeef = New System.Windows.Forms.RadioButton()
        Me.GrpBoxToppings = New System.Windows.Forms.GroupBox()
        Me.chkMayo = New System.Windows.Forms.CheckBox()
        Me.chkMustard = New System.Windows.Forms.CheckBox()
        Me.chkKetchup = New System.Windows.Forms.CheckBox()
        Me.chkGaucamole = New System.Windows.Forms.CheckBox()
        Me.chkCheese = New System.Windows.Forms.CheckBox()
        Me.chkBacon = New System.Windows.Forms.CheckBox()
        Me.chkPickles = New System.Windows.Forms.CheckBox()
        Me.chkTomato = New System.Windows.Forms.CheckBox()
        Me.chkOnion = New System.Windows.Forms.CheckBox()
        Me.chkLettuce = New System.Windows.Forms.CheckBox()
        Me.GrpBoxPrice = New System.Windows.Forms.GroupBox()
        Me.GrpBoxBeverage = New System.Windows.Forms.GroupBox()
        Me.GrpBoxSize = New System.Windows.Forms.GroupBox()
        Me.radLarge = New System.Windows.Forms.RadioButton()
        Me.radMedium = New System.Windows.Forms.RadioButton()
        Me.radSmall = New System.Windows.Forms.RadioButton()
        Me.radOrange = New System.Windows.Forms.RadioButton()
        Me.radCoffee = New System.Windows.Forms.RadioButton()
        Me.radWater = New System.Windows.Forms.RadioButton()
        Me.radSoda = New System.Windows.Forms.RadioButton()
        Me.radTea = New System.Windows.Forms.RadioButton()
        Me.lblMsg = New System.Windows.Forms.Label()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.picBlinking, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrpBoxBurger.SuspendLayout()
        Me.GrpBoxToppings.SuspendLayout()
        Me.GrpBoxPrice.SuspendLayout()
        Me.GrpBoxBeverage.SuspendLayout()
        Me.GrpBoxSize.SuspendLayout()
        Me.SuspendLayout()
        '
        'picBlinking
        '
        Me.picBlinking.Image = Global.BurgerProject_YounesOuladSaiad.My.Resources.Resources.burger
        Me.picBlinking.Location = New System.Drawing.Point(708, 579)
        Me.picBlinking.Name = "picBlinking"
        Me.picBlinking.Size = New System.Drawing.Size(304, 258)
        Me.picBlinking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picBlinking.TabIndex = 0
        Me.picBlinking.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.lblTitle.Font = New System.Drawing.Font("Papyrus", 28.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(586, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(482, 242)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "YNS's Fast Burger"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblToppings
        '
        Me.lblToppings.BackColor = System.Drawing.Color.Bisque
        Me.lblToppings.Font = New System.Drawing.Font("Papyrus", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToppings.Location = New System.Drawing.Point(6, 344)
        Me.lblToppings.Name = "lblToppings"
        Me.lblToppings.Size = New System.Drawing.Size(526, 95)
        Me.lblToppings.TabIndex = 6
        Me.lblToppings.Text = "Veggie toppings have an additional charge of $0.10 cents each, condiments are fre" &
    "e, bacon and guacamole are an additional $1.00"
        Me.lblToppings.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Subtotal
        '
        Me.Subtotal.AutoSize = True
        Me.Subtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Subtotal.Location = New System.Drawing.Point(10, 98)
        Me.Subtotal.Name = "Subtotal"
        Me.Subtotal.Size = New System.Drawing.Size(109, 29)
        Me.Subtotal.TabIndex = 13
        Me.Subtotal.Text = "Subtotal"
        '
        'Tax
        '
        Me.Tax.AutoSize = True
        Me.Tax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tax.Location = New System.Drawing.Point(34, 184)
        Me.Tax.Name = "Tax"
        Me.Tax.Size = New System.Drawing.Size(56, 29)
        Me.Tax.TabIndex = 14
        Me.Tax.Text = "Tax"
        '
        'Total
        '
        Me.Total.AutoSize = True
        Me.Total.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Total.Location = New System.Drawing.Point(17, 267)
        Me.Total.Name = "Total"
        Me.Total.Size = New System.Drawing.Size(73, 29)
        Me.Total.TabIndex = 15
        Me.Total.Text = "Total"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubtotal.Location = New System.Drawing.Point(134, 82)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(155, 49)
        Me.lblSubtotal.TabIndex = 16
        '
        'lblTax
        '
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTax.Location = New System.Drawing.Point(134, 171)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(155, 49)
        Me.lblTax.TabIndex = 17
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal.Location = New System.Drawing.Point(134, 254)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(155, 49)
        Me.lblTotal.TabIndex = 18
        '
        'btnTotal
        '
        Me.btnTotal.Font = New System.Drawing.Font("Tempus Sans ITC", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotal.Location = New System.Drawing.Point(335, 75)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(147, 56)
        Me.btnTotal.TabIndex = 19
        Me.btnTotal.Text = "Total"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Tempus Sans ITC", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.Location = New System.Drawing.Point(335, 160)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(147, 56)
        Me.btnReset.TabIndex = 20
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.AutoSize = True
        Me.btnExit.Font = New System.Drawing.Font("Tempus Sans ITC", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(335, 248)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(147, 56)
        Me.btnExit.TabIndex = 21
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'GrpBoxBurger
        '
        Me.GrpBoxBurger.BackColor = System.Drawing.Color.Silver
        Me.GrpBoxBurger.Controls.Add(Me.radBuffalo)
        Me.GrpBoxBurger.Controls.Add(Me.radVeggie)
        Me.GrpBoxBurger.Controls.Add(Me.radTurkey)
        Me.GrpBoxBurger.Controls.Add(Me.radBeef)
        Me.GrpBoxBurger.Font = New System.Drawing.Font("Papyrus", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpBoxBurger.Location = New System.Drawing.Point(46, 26)
        Me.GrpBoxBurger.Name = "GrpBoxBurger"
        Me.GrpBoxBurger.Size = New System.Drawing.Size(405, 256)
        Me.GrpBoxBurger.TabIndex = 22
        Me.GrpBoxBurger.TabStop = False
        Me.GrpBoxBurger.Text = "Pick Your Burger : "
        '
        'radBuffalo
        '
        Me.radBuffalo.AutoSize = True
        Me.radBuffalo.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBuffalo.Location = New System.Drawing.Point(29, 173)
        Me.radBuffalo.Name = "radBuffalo"
        Me.radBuffalo.Size = New System.Drawing.Size(310, 42)
        Me.radBuffalo.TabIndex = 3
        Me.radBuffalo.TabStop = True
        Me.radBuffalo.Text = "Buffalo                   $6:00"
        Me.radBuffalo.UseVisualStyleBackColor = True
        '
        'radVeggie
        '
        Me.radVeggie.AutoSize = True
        Me.radVeggie.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radVeggie.Location = New System.Drawing.Point(29, 134)
        Me.radVeggie.Name = "radVeggie"
        Me.radVeggie.Size = New System.Drawing.Size(309, 42)
        Me.radVeggie.TabIndex = 2
        Me.radVeggie.TabStop = True
        Me.radVeggie.Text = "Veggie                    $5:00"
        Me.radVeggie.UseVisualStyleBackColor = True
        '
        'radTurkey
        '
        Me.radTurkey.AutoSize = True
        Me.radTurkey.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTurkey.Location = New System.Drawing.Point(29, 95)
        Me.radTurkey.Name = "radTurkey"
        Me.radTurkey.Size = New System.Drawing.Size(312, 42)
        Me.radTurkey.TabIndex = 1
        Me.radTurkey.TabStop = True
        Me.radTurkey.Text = "Turkey                    $4:25"
        Me.radTurkey.UseVisualStyleBackColor = True
        '
        'radBeef
        '
        Me.radBeef.AutoSize = True
        Me.radBeef.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBeef.Location = New System.Drawing.Point(29, 59)
        Me.radBeef.Name = "radBeef"
        Me.radBeef.Size = New System.Drawing.Size(311, 42)
        Me.radBeef.TabIndex = 0
        Me.radBeef.TabStop = True
        Me.radBeef.Text = "Beef                        $4:00"
        Me.radBeef.UseVisualStyleBackColor = True
        '
        'GrpBoxToppings
        '
        Me.GrpBoxToppings.BackColor = System.Drawing.Color.Wheat
        Me.GrpBoxToppings.Controls.Add(Me.chkMayo)
        Me.GrpBoxToppings.Controls.Add(Me.chkMustard)
        Me.GrpBoxToppings.Controls.Add(Me.chkKetchup)
        Me.GrpBoxToppings.Controls.Add(Me.chkGaucamole)
        Me.GrpBoxToppings.Controls.Add(Me.chkCheese)
        Me.GrpBoxToppings.Controls.Add(Me.chkBacon)
        Me.GrpBoxToppings.Controls.Add(Me.chkPickles)
        Me.GrpBoxToppings.Controls.Add(Me.chkTomato)
        Me.GrpBoxToppings.Controls.Add(Me.chkOnion)
        Me.GrpBoxToppings.Controls.Add(Me.chkLettuce)
        Me.GrpBoxToppings.Controls.Add(Me.lblToppings)
        Me.GrpBoxToppings.Font = New System.Drawing.Font("Papyrus", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpBoxToppings.Location = New System.Drawing.Point(26, 395)
        Me.GrpBoxToppings.Name = "GrpBoxToppings"
        Me.GrpBoxToppings.Size = New System.Drawing.Size(548, 442)
        Me.GrpBoxToppings.TabIndex = 23
        Me.GrpBoxToppings.TabStop = False
        Me.GrpBoxToppings.Text = "Pick Your Toppings :"
        '
        'chkMayo
        '
        Me.chkMayo.AutoSize = True
        Me.chkMayo.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMayo.Location = New System.Drawing.Point(239, 269)
        Me.chkMayo.Name = "chkMayo"
        Me.chkMayo.Size = New System.Drawing.Size(109, 42)
        Me.chkMayo.TabIndex = 9
        Me.chkMayo.Text = "Mayo"
        Me.chkMayo.UseVisualStyleBackColor = True
        '
        'chkMustard
        '
        Me.chkMustard.AutoSize = True
        Me.chkMustard.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMustard.Location = New System.Drawing.Point(239, 221)
        Me.chkMustard.Name = "chkMustard"
        Me.chkMustard.Size = New System.Drawing.Size(226, 42)
        Me.chkMustard.TabIndex = 8
        Me.chkMustard.Text = "Honey Mustard"
        Me.chkMustard.UseVisualStyleBackColor = True
        '
        'chkKetchup
        '
        Me.chkKetchup.AutoSize = True
        Me.chkKetchup.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkKetchup.Location = New System.Drawing.Point(239, 174)
        Me.chkKetchup.Name = "chkKetchup"
        Me.chkKetchup.Size = New System.Drawing.Size(144, 42)
        Me.chkKetchup.TabIndex = 7
        Me.chkKetchup.Text = "Ketchup"
        Me.chkKetchup.UseVisualStyleBackColor = True
        '
        'chkGaucamole
        '
        Me.chkGaucamole.AutoSize = True
        Me.chkGaucamole.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkGaucamole.Location = New System.Drawing.Point(239, 126)
        Me.chkGaucamole.Name = "chkGaucamole"
        Me.chkGaucamole.Size = New System.Drawing.Size(170, 42)
        Me.chkGaucamole.TabIndex = 6
        Me.chkGaucamole.Text = "Gaucamole"
        Me.chkGaucamole.UseVisualStyleBackColor = True
        '
        'chkCheese
        '
        Me.chkCheese.AutoSize = True
        Me.chkCheese.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCheese.Location = New System.Drawing.Point(239, 78)
        Me.chkCheese.Name = "chkCheese"
        Me.chkCheese.Size = New System.Drawing.Size(136, 42)
        Me.chkCheese.TabIndex = 5
        Me.chkCheese.Text = "Cheese"
        Me.chkCheese.UseVisualStyleBackColor = True
        '
        'chkBacon
        '
        Me.chkBacon.AutoSize = True
        Me.chkBacon.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBacon.Location = New System.Drawing.Point(29, 272)
        Me.chkBacon.Name = "chkBacon"
        Me.chkBacon.Size = New System.Drawing.Size(119, 42)
        Me.chkBacon.TabIndex = 4
        Me.chkBacon.Text = "Bacon"
        Me.chkBacon.UseVisualStyleBackColor = True
        '
        'chkPickles
        '
        Me.chkPickles.AutoSize = True
        Me.chkPickles.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPickles.Location = New System.Drawing.Point(29, 224)
        Me.chkPickles.Name = "chkPickles"
        Me.chkPickles.Size = New System.Drawing.Size(123, 42)
        Me.chkPickles.TabIndex = 3
        Me.chkPickles.Text = "Pickles"
        Me.chkPickles.UseVisualStyleBackColor = True
        '
        'chkTomato
        '
        Me.chkTomato.AutoSize = True
        Me.chkTomato.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTomato.Location = New System.Drawing.Point(29, 128)
        Me.chkTomato.Name = "chkTomato"
        Me.chkTomato.Size = New System.Drawing.Size(134, 42)
        Me.chkTomato.TabIndex = 2
        Me.chkTomato.Text = "Tomato"
        Me.chkTomato.UseVisualStyleBackColor = True
        '
        'chkOnion
        '
        Me.chkOnion.AutoSize = True
        Me.chkOnion.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnion.Location = New System.Drawing.Point(29, 176)
        Me.chkOnion.Name = "chkOnion"
        Me.chkOnion.Size = New System.Drawing.Size(116, 42)
        Me.chkOnion.TabIndex = 1
        Me.chkOnion.Text = "Onion"
        Me.chkOnion.UseVisualStyleBackColor = True
        '
        'chkLettuce
        '
        Me.chkLettuce.AutoSize = True
        Me.chkLettuce.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLettuce.Location = New System.Drawing.Point(29, 78)
        Me.chkLettuce.Name = "chkLettuce"
        Me.chkLettuce.Size = New System.Drawing.Size(136, 42)
        Me.chkLettuce.TabIndex = 0
        Me.chkLettuce.Text = "Lettuce"
        Me.chkLettuce.UseVisualStyleBackColor = True
        '
        'GrpBoxPrice
        '
        Me.GrpBoxPrice.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GrpBoxPrice.Controls.Add(Me.btnExit)
        Me.GrpBoxPrice.Controls.Add(Me.Subtotal)
        Me.GrpBoxPrice.Controls.Add(Me.Tax)
        Me.GrpBoxPrice.Controls.Add(Me.Total)
        Me.GrpBoxPrice.Controls.Add(Me.btnReset)
        Me.GrpBoxPrice.Controls.Add(Me.lblSubtotal)
        Me.GrpBoxPrice.Controls.Add(Me.btnTotal)
        Me.GrpBoxPrice.Controls.Add(Me.lblTax)
        Me.GrpBoxPrice.Controls.Add(Me.lblTotal)
        Me.GrpBoxPrice.Font = New System.Drawing.Font("Papyrus", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpBoxPrice.Location = New System.Drawing.Point(1122, 456)
        Me.GrpBoxPrice.Name = "GrpBoxPrice"
        Me.GrpBoxPrice.Size = New System.Drawing.Size(499, 326)
        Me.GrpBoxPrice.TabIndex = 24
        Me.GrpBoxPrice.TabStop = False
        Me.GrpBoxPrice.Text = "Price"
        '
        'GrpBoxBeverage
        '
        Me.GrpBoxBeverage.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GrpBoxBeverage.Controls.Add(Me.GrpBoxSize)
        Me.GrpBoxBeverage.Controls.Add(Me.radOrange)
        Me.GrpBoxBeverage.Controls.Add(Me.radCoffee)
        Me.GrpBoxBeverage.Controls.Add(Me.radWater)
        Me.GrpBoxBeverage.Controls.Add(Me.radSoda)
        Me.GrpBoxBeverage.Controls.Add(Me.radTea)
        Me.GrpBoxBeverage.Font = New System.Drawing.Font("Papyrus", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpBoxBeverage.Location = New System.Drawing.Point(1170, 98)
        Me.GrpBoxBeverage.Name = "GrpBoxBeverage"
        Me.GrpBoxBeverage.Size = New System.Drawing.Size(451, 304)
        Me.GrpBoxBeverage.TabIndex = 25
        Me.GrpBoxBeverage.TabStop = False
        Me.GrpBoxBeverage.Text = "Pick Your Beverage :"
        '
        'GrpBoxSize
        '
        Me.GrpBoxSize.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GrpBoxSize.Controls.Add(Me.radLarge)
        Me.GrpBoxSize.Controls.Add(Me.radMedium)
        Me.GrpBoxSize.Controls.Add(Me.radSmall)
        Me.GrpBoxSize.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpBoxSize.Location = New System.Drawing.Point(239, 131)
        Me.GrpBoxSize.Name = "GrpBoxSize"
        Me.GrpBoxSize.Size = New System.Drawing.Size(212, 173)
        Me.GrpBoxSize.TabIndex = 5
        Me.GrpBoxSize.TabStop = False
        Me.GrpBoxSize.Text = "Size"
        '
        'radLarge
        '
        Me.radLarge.AutoSize = True
        Me.radLarge.Font = New System.Drawing.Font("Papyrus", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radLarge.Location = New System.Drawing.Point(6, 104)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(195, 38)
        Me.radLarge.TabIndex = 2
        Me.radLarge.TabStop = True
        Me.radLarge.Text = "Large.....$2:50"
        Me.radLarge.UseVisualStyleBackColor = True
        '
        'radMedium
        '
        Me.radMedium.AutoSize = True
        Me.radMedium.Font = New System.Drawing.Font("Papyrus", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radMedium.Location = New System.Drawing.Point(6, 69)
        Me.radMedium.Name = "radMedium"
        Me.radMedium.Size = New System.Drawing.Size(208, 38)
        Me.radMedium.TabIndex = 1
        Me.radMedium.TabStop = True
        Me.radMedium.Text = "Medium... $2:00"
        Me.radMedium.UseVisualStyleBackColor = True
        '
        'radSmall
        '
        Me.radSmall.AutoSize = True
        Me.radSmall.Font = New System.Drawing.Font("Papyrus", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radSmall.Location = New System.Drawing.Point(6, 38)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(199, 38)
        Me.radSmall.TabIndex = 0
        Me.radSmall.TabStop = True
        Me.radSmall.Text = "Small..... $1.50"
        Me.radSmall.UseVisualStyleBackColor = True
        '
        'radOrange
        '
        Me.radOrange.AutoSize = True
        Me.radOrange.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOrange.Location = New System.Drawing.Point(27, 255)
        Me.radOrange.Name = "radOrange"
        Me.radOrange.Size = New System.Drawing.Size(201, 42)
        Me.radOrange.TabIndex = 4
        Me.radOrange.TabStop = True
        Me.radOrange.Text = "Orange Juice"
        Me.radOrange.UseVisualStyleBackColor = True
        '
        'radCoffee
        '
        Me.radCoffee.AutoSize = True
        Me.radCoffee.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCoffee.Location = New System.Drawing.Point(27, 207)
        Me.radCoffee.Name = "radCoffee"
        Me.radCoffee.Size = New System.Drawing.Size(127, 42)
        Me.radCoffee.TabIndex = 3
        Me.radCoffee.TabStop = True
        Me.radCoffee.Text = "Coffee"
        Me.radCoffee.UseVisualStyleBackColor = True
        '
        'radWater
        '
        Me.radWater.AutoSize = True
        Me.radWater.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radWater.Location = New System.Drawing.Point(27, 159)
        Me.radWater.Name = "radWater"
        Me.radWater.Size = New System.Drawing.Size(185, 42)
        Me.radWater.TabIndex = 2
        Me.radWater.TabStop = True
        Me.radWater.Text = "Water (free)"
        Me.radWater.UseVisualStyleBackColor = True
        '
        'radSoda
        '
        Me.radSoda.AutoSize = True
        Me.radSoda.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radSoda.Location = New System.Drawing.Point(27, 111)
        Me.radSoda.Name = "radSoda"
        Me.radSoda.Size = New System.Drawing.Size(107, 42)
        Me.radSoda.TabIndex = 1
        Me.radSoda.TabStop = True
        Me.radSoda.Text = "Soda"
        Me.radSoda.UseVisualStyleBackColor = True
        '
        'radTea
        '
        Me.radTea.AutoSize = True
        Me.radTea.Font = New System.Drawing.Font("Papyrus", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTea.Location = New System.Drawing.Point(27, 63)
        Me.radTea.Name = "radTea"
        Me.radTea.Size = New System.Drawing.Size(93, 42)
        Me.radTea.TabIndex = 0
        Me.radTea.TabStop = True
        Me.radTea.Text = "Tea"
        Me.radTea.UseVisualStyleBackColor = True
        '
        'lblMsg
        '
        Me.lblMsg.AutoSize = True
        Me.lblMsg.ForeColor = System.Drawing.Color.Red
        Me.lblMsg.Location = New System.Drawing.Point(1055, 799)
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.Size = New System.Drawing.Size(0, 20)
        Me.lblMsg.TabIndex = 26
        '
        'Timer
        '
        Me.Timer.Interval = 1100
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1679, 849)
        Me.Controls.Add(Me.lblMsg)
        Me.Controls.Add(Me.GrpBoxBeverage)
        Me.Controls.Add(Me.GrpBoxPrice)
        Me.Controls.Add(Me.GrpBoxToppings)
        Me.Controls.Add(Me.GrpBoxBurger)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picBlinking)
        Me.Name = "Form1"
        Me.Text = "MENU PROGRAM"
        CType(Me.picBlinking, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrpBoxBurger.ResumeLayout(False)
        Me.GrpBoxBurger.PerformLayout()
        Me.GrpBoxToppings.ResumeLayout(False)
        Me.GrpBoxToppings.PerformLayout()
        Me.GrpBoxPrice.ResumeLayout(False)
        Me.GrpBoxPrice.PerformLayout()
        Me.GrpBoxBeverage.ResumeLayout(False)
        Me.GrpBoxBeverage.PerformLayout()
        Me.GrpBoxSize.ResumeLayout(False)
        Me.GrpBoxSize.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picBlinking As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblToppings As Label
    Friend WithEvents Subtotal As Label
    Friend WithEvents Tax As Label
    Friend WithEvents Total As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnTotal As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents GrpBoxBurger As GroupBox
    Friend WithEvents radBuffalo As RadioButton
    Friend WithEvents radVeggie As RadioButton
    Friend WithEvents radTurkey As RadioButton
    Friend WithEvents radBeef As RadioButton
    Friend WithEvents GrpBoxToppings As GroupBox
    Friend WithEvents chkMayo As CheckBox
    Friend WithEvents chkMustard As CheckBox
    Friend WithEvents chkKetchup As CheckBox
    Friend WithEvents chkGaucamole As CheckBox
    Friend WithEvents chkCheese As CheckBox
    Friend WithEvents chkBacon As CheckBox
    Friend WithEvents chkPickles As CheckBox
    Friend WithEvents chkTomato As CheckBox
    Friend WithEvents chkOnion As CheckBox
    Friend WithEvents chkLettuce As CheckBox
    Friend WithEvents GrpBoxPrice As GroupBox
    Friend WithEvents GrpBoxBeverage As GroupBox
    Friend WithEvents GrpBoxSize As GroupBox
    Friend WithEvents radLarge As RadioButton
    Friend WithEvents radMedium As RadioButton
    Friend WithEvents radSmall As RadioButton
    Friend WithEvents radOrange As RadioButton
    Friend WithEvents radCoffee As RadioButton
    Friend WithEvents radWater As RadioButton
    Friend WithEvents radSoda As RadioButton
    Friend WithEvents radTea As RadioButton
    Friend WithEvents lblMsg As Label
    Friend WithEvents Timer As Timer
End Class
