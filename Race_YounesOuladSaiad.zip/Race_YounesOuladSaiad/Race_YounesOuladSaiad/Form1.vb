﻿Public Class Form1
    ' Younes Oulad Saiad
    ' 10 Nov 2023


    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'DECLARE VARIABLES

        Dim race1_boat1, race1_boat2, race1_boat3, race2_boat1,
            race2_boat2, race2_boat3, race3_boat1, race3_boat2,
            race3_boat3, race4_boat1, race4_boat2, race4_boat3 As Integer


        Dim totalRace1 As Integer
        Dim totalRace2 As Integer
        Dim totalRace3 As Integer
        Dim totalRace4 As Integer


        Dim boat1_total As Integer
        Dim boat2_total As Integer
        Dim boat3_total As Integer


        ' ASSIGN VARIABLES
        Try
            totalRace1 = race1_boat1 + race1_boat2 + race1_boat3
            totalRace2 = race2_boat1 + race2_boat2 + race2_boat3
            totalRace3 = race3_boat1 + race3_boat2 + race3_boat3
            totalRace4 = race4_boat1 + race4_boat2 + race4_boat3

            boat1_total = race1_boat1 + race2_boat1 + race3_boat1 + race4_boat1
            boat2_total = race1_boat2 + race2_boat2 + race3_boat2 + race4_boat2
            boat3_total = race1_boat3 + race2_boat3 + race3_boat3 + race4_boat3


            'PERFORM CALCULATION

            If Integer.TryParse(txtB1R1.Text, race1_boat1) AndAlso
                   Integer.TryParse(txtB2R1.Text, race1_boat2) AndAlso
                   Integer.TryParse(txtB3R1.Text, race1_boat3) AndAlso
                   Integer.TryParse(txtB1R2.Text, race2_boat1) AndAlso
                   Integer.TryParse(txtB2R2.Text, race2_boat2) AndAlso
                   Integer.TryParse(txtB3R2.Text, race2_boat3) AndAlso
                   Integer.TryParse(txtB1R3.Text, race3_boat1) AndAlso
                   Integer.TryParse(txtB2R3.Text, race3_boat2) AndAlso
                   Integer.TryParse(txtB3R3.Text, race3_boat3) AndAlso
                   Integer.TryParse(txtB1R4.Text, race4_boat1) AndAlso
                   Integer.TryParse(txtB2R4.Text, race4_boat2) AndAlso
                   Integer.TryParse(txtB3R4.Text, race4_boat3) Then

                totalRace1 = race1_boat1 + race1_boat2 + race1_boat3
                totalRace2 = race2_boat1 + race2_boat2 + race2_boat3
                totalRace3 = race3_boat1 + race3_boat2 + race3_boat3
                totalRace4 = race4_boat1 + race4_boat2 + race4_boat3





                If totalRace1 = 6 AndAlso totalRace2 = 6 AndAlso totalRace3 = 6 AndAlso totalRace4 = 6 Then

                    boat1_total = race1_boat1 + race2_boat1 + race3_boat1 + race4_boat1
                    boat2_total = race1_boat2 + race2_boat2 + race3_boat2 + race4_boat2
                    boat3_total = race1_boat3 + race2_boat3 + race3_boat3 + race4_boat3






                    Dim boatRank As New List(Of Integer)({boat1_total, boat2_total, boat3_total})
                    boatRank.Sort()
                    boatRank.Reverse()

                    lblT1.Text = boat1_total.ToString()
                    lblT2.Text = boat2_total.ToString()
                    lblT3.Text = boat3_total.ToString()

                    lblRank1.Text = (boatRank.IndexOf(boat1_total) + 1).ToString()
                    lblRank2.Text = (boatRank.IndexOf(boat2_total) + 1).ToString()
                    lblRank3.Text = (boatRank.IndexOf(boat3_total) + 1).ToString()

                    ' DISPLAY OUTPUT
                Else

                    MessageBox.Show("Each race column must add up to 6.")

                End If
            Else

                MessageBox.Show("Please enter valid integer values for all races.")

            End If




            If lblT1.Text = lblT2.Text = lblT3.Text Then

                lblStatus.Text = "TIE"



                lblRank1.ForeColor = Color.Red
                lblRank2.ForeColor = Color.Red
                lblRank3.ForeColor = Color.Red
            End If
        Catch
            MessageBox.Show("Error")
        End Try

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtB1R1.Text = ""
        txtB2R1.Text = ""
        txtB3R1.Text = ""
        txtB1R2.Text = ""
        txtB2R2.Text = ""
        txtB3R2.Text = ""
        txtB1R3.Text = ""
        txtB2R3.Text = ""
        txtB3R3.Text = ""
        txtB1R4.Text = ""
        txtB2R4.Text = ""
        txtB3R4.Text = ""
        lblT1.Text = ""
        lblT2.Text = ""
        lblT3.Text = ""
        lblRank1.Text = ""
        lblRank2.Text = ""
        lblRank3.Text = ""
        lblStatus.Text = ""



    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    'THIS EXERCISE WAS VERY CHALLENGING FOR ME, I TRIED TO DO MY BEST 
    'THANK YOU,
    'YOUNES

End Class






















































































