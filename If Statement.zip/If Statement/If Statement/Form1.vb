﻿Public Class Form1
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click


        'Declare Variables

        Dim dblGrade As Double



        'Assign Variables

        dblGrade = txtGrade.Text





        'Perform Calculations
        If dblGrade <= 60 Then
            lblGrade.Text = "F"
        ElseIf dblGrade < 70 Then
            lblGrade.Text = "D"
        ElseIf dblGrade < 80 Then
            lblGrade.Text = "C"
        ElseIf dblGrade < 90 Then
            lblGrade.Text = "B"
        ElseIf dblGrade <= 100 Then
            lblGrade.Text = "A"


        Else
            MessageBox.Show("Wach Nti Mssatia")

        End If




        'Display Output




    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblGrade.Text = ""
        txtGrade.Text = ""
    End Sub
End Class
