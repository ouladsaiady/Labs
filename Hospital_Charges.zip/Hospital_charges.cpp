// Name: Younes Oulad Saiad
// Prof: Sylvia Yeung
// Summary: Exercise Hospital charges
// the most difficult aspect is creating the ofstream
// It took me about 2h to write this code
// 4-17-2024 start working on this assignment
// 4-20-2024 rev. and adding comments and organized the code

/* The complete chart based on the exercise’s requirement 

This program will compute patient hospital charges.
Enter I for in-patient or O for out-patient: i


Number of days in the hospital: 2
Daily room rate:  $300
Lab fees and other services charges(lab tests, etc.):  $400
Medication charges:  $100

The billing report has been written to the hospital.txt file

*/ 


#include <iostream> // Include the input/output stream library
#include <fstream>  // Include the file stream library
#include <string>   // Include the string librar

using namespace std; // Use the standard namespace

// Function to validate input data

double validateData(double data, string prompt) {
    while (data < 0) {
        cout << "Invalid input! " << prompt << " cannot be negative. Please re-enter: ";
        cin >> data;
    }
    return data;
}

// Function to calculate total charges for inpatient

double patientCharges( double dailyRate, double serviceCharges, double medicationCharges) {
    return  dailyRate + serviceCharges + medicationCharges;
}

// Function to calculate total charges for outpatient

double patientCharges(double serviceCharges, double medicationCharges) {
    return serviceCharges + medicationCharges;
}

int main() {
    // Open the output file

    ofstream outputFile("hospital.txt");

// Ask the user if the patient was an inpatient or an outpatient

    char patientType;
    do { // loop until the right input
    cout<<"This program will compute patient hospital charges."<<endl;
    cout << "Enter I for in-patient or O for out-patient: ";
    cin >> patientType;
    cout<<endl; // Print an empty line

    // validate the input

    if (patientType != 'I' && patientType != 'i' && patientType != 'O' && patientType != 'o') {
            cout << "Please enter a valid option ('I' for inpatient or 'O' for outpatient)." << endl;
        }
    cout<<endl;
    } while (patientType != 'I' && patientType != 'i' && patientType != 'O' && patientType != 'o');

    // Process the input: inpatient

    if (patientType == 'I' || patientType == 'i') {
        int days;
        double dailyRate, serviceCharges, medicationCharges;

// Enter the numbers of days

        cout << "Number of days in the hospital: ";
        cin >> days;
        days = validateData(days, "Number of days");

// Enter the daily room rate

        cout << "Daily room rate:  $";
        cin >> dailyRate;
        dailyRate = validateData(dailyRate, "Daily rate");

// Enter the charges

        cout << "Lab fees and other services charges(lab tests, etc.):  $";
        cin >> serviceCharges;
        serviceCharges = validateData(serviceCharges, "Service charges");

// Enter the medication charges

        cout << "Medication charges:  $";
        cin >> medicationCharges;
        medicationCharges = validateData(medicationCharges, "Medication charges");

// Calculate total charges for inpatient

        double totalCharges = patientCharges(dailyRate, serviceCharges, medicationCharges);

    // save the output in the hospital.txt

        outputFile << "**************************" << endl;
        outputFile << "Hospital Billing Statement" << endl;
        outputFile << "**************************" << endl;
        outputFile << "Room charges: $" << dailyRate << endl;
        outputFile <<"Lab & Services:  $" << serviceCharges << endl;
        outputFile << "Medication: $" << medicationCharges << endl;
        outputFile << "Total Charges: $" << totalCharges << endl;
        outputFile << "**************************" << endl;
        cout<<endl; // Print an empty line
        

        cout << "The billing report has been written to the hospital.txt file" << endl;

// Process the input: outpatient

    } else if (patientType == 'O' || patientType == 'o') {
        double serviceCharges, medicationCharges;

// Enter the hospital charges 

        cout << "Charges for hospital services(lab tests, etc.): ";
        cin >> serviceCharges;
        serviceCharges = validateData(serviceCharges, "Service charges");

// Enter the Medication charges

        cout << "Medication charges: ";
        cin >> medicationCharges;
        medicationCharges = validateData(medicationCharges, "Medication charges");

// Calculate total charges for outpatient

        double totalCharges = patientCharges(serviceCharges, medicationCharges);

// save output in hospital.txt

        outputFile << "**************************" << endl;
        outputFile << "Hospital Billing Statement" << endl;
        outputFile << "**************************" << endl;
        outputFile << "Service Charges: $" << serviceCharges << endl;
        outputFile << "Medication Charges: $" << medicationCharges << endl;
        outputFile << "**************************" << endl;
        outputFile << "Total Charges: $" << totalCharges << endl;
        cout<<endl;// Print an empty line
        cout << "The billing report has been written to the hospital.txt file" << endl;
    } 

    outputFile.close(); // close the file

    return 0; // no return
} // end of program
