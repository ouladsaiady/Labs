﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblB1 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblR4 = New System.Windows.Forms.Label()
        Me.lblR3 = New System.Windows.Forms.Label()
        Me.lblR2 = New System.Windows.Forms.Label()
        Me.lblRank = New System.Windows.Forms.Label()
        Me.lblR1 = New System.Windows.Forms.Label()
        Me.lblT1 = New System.Windows.Forms.Label()
        Me.lblRank1 = New System.Windows.Forms.Label()
        Me.txtB1R1 = New System.Windows.Forms.TextBox()
        Me.txtB1R2 = New System.Windows.Forms.TextBox()
        Me.txtB1R3 = New System.Windows.Forms.TextBox()
        Me.txtB1R4 = New System.Windows.Forms.TextBox()
        Me.txtB2R4 = New System.Windows.Forms.TextBox()
        Me.txtB2R3 = New System.Windows.Forms.TextBox()
        Me.txtB2R2 = New System.Windows.Forms.TextBox()
        Me.txtB2R1 = New System.Windows.Forms.TextBox()
        Me.lblRank2 = New System.Windows.Forms.Label()
        Me.lblT2 = New System.Windows.Forms.Label()
        Me.lblB2 = New System.Windows.Forms.Label()
        Me.txtB3R4 = New System.Windows.Forms.TextBox()
        Me.txtB3R3 = New System.Windows.Forms.TextBox()
        Me.txtB3R2 = New System.Windows.Forms.TextBox()
        Me.txtB3R1 = New System.Windows.Forms.TextBox()
        Me.lblRank3 = New System.Windows.Forms.Label()
        Me.lblT3 = New System.Windows.Forms.Label()
        Me.lblB3 = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCalculate.Location = New System.Drawing.Point(57, 500)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(375, 93)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate Rankings"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClear.Location = New System.Drawing.Point(480, 500)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(375, 93)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnExit.Location = New System.Drawing.Point(1314, 500)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(191, 93)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblB1
        '
        Me.lblB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblB1.Location = New System.Drawing.Point(52, 167)
        Me.lblB1.Name = "lblB1"
        Me.lblB1.Size = New System.Drawing.Size(182, 52)
        Me.lblB1.TabIndex = 3
        Me.lblB1.Text = "Boat #1"
        Me.lblB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotal
        '
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTotal.Location = New System.Drawing.Point(1078, 64)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(182, 52)
        Me.lblTotal.TabIndex = 4
        Me.lblTotal.Text = "Total"
        Me.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblR4
        '
        Me.lblR4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblR4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblR4.Location = New System.Drawing.Point(861, 64)
        Me.lblR4.Name = "lblR4"
        Me.lblR4.Size = New System.Drawing.Size(182, 52)
        Me.lblR4.TabIndex = 5
        Me.lblR4.Text = "Race 4"
        Me.lblR4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblR3
        '
        Me.lblR3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblR3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblR3.Location = New System.Drawing.Point(645, 64)
        Me.lblR3.Name = "lblR3"
        Me.lblR3.Size = New System.Drawing.Size(182, 52)
        Me.lblR3.TabIndex = 6
        Me.lblR3.Text = "Race 3"
        Me.lblR3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblR2
        '
        Me.lblR2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblR2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblR2.Location = New System.Drawing.Point(438, 64)
        Me.lblR2.Name = "lblR2"
        Me.lblR2.Size = New System.Drawing.Size(182, 52)
        Me.lblR2.TabIndex = 7
        Me.lblR2.Text = "Race 2"
        Me.lblR2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRank
        '
        Me.lblRank.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRank.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblRank.Location = New System.Drawing.Point(1300, 64)
        Me.lblRank.Name = "lblRank"
        Me.lblRank.Size = New System.Drawing.Size(182, 52)
        Me.lblRank.TabIndex = 8
        Me.lblRank.Text = "Rank"
        Me.lblRank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblR1
        '
        Me.lblR1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblR1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblR1.Location = New System.Drawing.Point(250, 64)
        Me.lblR1.Name = "lblR1"
        Me.lblR1.Size = New System.Drawing.Size(182, 52)
        Me.lblR1.TabIndex = 9
        Me.lblR1.Text = "Race 1"
        Me.lblR1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblT1
        '
        Me.lblT1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblT1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblT1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblT1.Location = New System.Drawing.Point(1078, 162)
        Me.lblT1.Name = "lblT1"
        Me.lblT1.Size = New System.Drawing.Size(185, 63)
        Me.lblT1.TabIndex = 12
        Me.lblT1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRank1
        '
        Me.lblRank1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRank1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblRank1.Location = New System.Drawing.Point(1305, 162)
        Me.lblRank1.Name = "lblRank1"
        Me.lblRank1.Size = New System.Drawing.Size(185, 63)
        Me.lblRank1.TabIndex = 15
        Me.lblRank1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtB1R1
        '
        Me.txtB1R1.Location = New System.Drawing.Point(273, 162)
        Me.txtB1R1.Multiline = True
        Me.txtB1R1.Name = "txtB1R1"
        Me.txtB1R1.Size = New System.Drawing.Size(143, 59)
        Me.txtB1R1.TabIndex = 18
        Me.txtB1R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB1R2
        '
        Me.txtB1R2.Location = New System.Drawing.Point(454, 162)
        Me.txtB1R2.Multiline = True
        Me.txtB1R2.Name = "txtB1R2"
        Me.txtB1R2.Size = New System.Drawing.Size(143, 59)
        Me.txtB1R2.TabIndex = 19
        Me.txtB1R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB1R3
        '
        Me.txtB1R3.Location = New System.Drawing.Point(661, 162)
        Me.txtB1R3.Multiline = True
        Me.txtB1R3.Name = "txtB1R3"
        Me.txtB1R3.Size = New System.Drawing.Size(143, 59)
        Me.txtB1R3.TabIndex = 20
        Me.txtB1R3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB1R4
        '
        Me.txtB1R4.Location = New System.Drawing.Point(881, 162)
        Me.txtB1R4.Multiline = True
        Me.txtB1R4.Name = "txtB1R4"
        Me.txtB1R4.Size = New System.Drawing.Size(143, 59)
        Me.txtB1R4.TabIndex = 21
        Me.txtB1R4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB2R4
        '
        Me.txtB2R4.Location = New System.Drawing.Point(881, 262)
        Me.txtB2R4.Multiline = True
        Me.txtB2R4.Name = "txtB2R4"
        Me.txtB2R4.Size = New System.Drawing.Size(143, 59)
        Me.txtB2R4.TabIndex = 28
        Me.txtB2R4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB2R3
        '
        Me.txtB2R3.Location = New System.Drawing.Point(661, 262)
        Me.txtB2R3.Multiline = True
        Me.txtB2R3.Name = "txtB2R3"
        Me.txtB2R3.Size = New System.Drawing.Size(143, 59)
        Me.txtB2R3.TabIndex = 27
        Me.txtB2R3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB2R2
        '
        Me.txtB2R2.Location = New System.Drawing.Point(454, 262)
        Me.txtB2R2.Multiline = True
        Me.txtB2R2.Name = "txtB2R2"
        Me.txtB2R2.Size = New System.Drawing.Size(143, 59)
        Me.txtB2R2.TabIndex = 26
        Me.txtB2R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB2R1
        '
        Me.txtB2R1.Location = New System.Drawing.Point(273, 262)
        Me.txtB2R1.Multiline = True
        Me.txtB2R1.Name = "txtB2R1"
        Me.txtB2R1.Size = New System.Drawing.Size(143, 59)
        Me.txtB2R1.TabIndex = 25
        Me.txtB2R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblRank2
        '
        Me.lblRank2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRank2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblRank2.Location = New System.Drawing.Point(1305, 262)
        Me.lblRank2.Name = "lblRank2"
        Me.lblRank2.Size = New System.Drawing.Size(185, 63)
        Me.lblRank2.TabIndex = 24
        Me.lblRank2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblT2
        '
        Me.lblT2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblT2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblT2.Location = New System.Drawing.Point(1078, 262)
        Me.lblT2.Name = "lblT2"
        Me.lblT2.Size = New System.Drawing.Size(185, 63)
        Me.lblT2.TabIndex = 23
        Me.lblT2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblB2
        '
        Me.lblB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblB2.Location = New System.Drawing.Point(52, 267)
        Me.lblB2.Name = "lblB2"
        Me.lblB2.Size = New System.Drawing.Size(182, 52)
        Me.lblB2.TabIndex = 22
        Me.lblB2.Text = "Boat #2"
        Me.lblB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtB3R4
        '
        Me.txtB3R4.Location = New System.Drawing.Point(881, 368)
        Me.txtB3R4.Multiline = True
        Me.txtB3R4.Name = "txtB3R4"
        Me.txtB3R4.Size = New System.Drawing.Size(143, 59)
        Me.txtB3R4.TabIndex = 35
        Me.txtB3R4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB3R3
        '
        Me.txtB3R3.Location = New System.Drawing.Point(661, 368)
        Me.txtB3R3.Multiline = True
        Me.txtB3R3.Name = "txtB3R3"
        Me.txtB3R3.Size = New System.Drawing.Size(143, 59)
        Me.txtB3R3.TabIndex = 34
        Me.txtB3R3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB3R2
        '
        Me.txtB3R2.Location = New System.Drawing.Point(454, 368)
        Me.txtB3R2.Multiline = True
        Me.txtB3R2.Name = "txtB3R2"
        Me.txtB3R2.Size = New System.Drawing.Size(143, 59)
        Me.txtB3R2.TabIndex = 33
        Me.txtB3R2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtB3R1
        '
        Me.txtB3R1.Location = New System.Drawing.Point(273, 368)
        Me.txtB3R1.Multiline = True
        Me.txtB3R1.Name = "txtB3R1"
        Me.txtB3R1.Size = New System.Drawing.Size(143, 59)
        Me.txtB3R1.TabIndex = 32
        Me.txtB3R1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblRank3
        '
        Me.lblRank3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRank3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblRank3.Location = New System.Drawing.Point(1305, 368)
        Me.lblRank3.Name = "lblRank3"
        Me.lblRank3.Size = New System.Drawing.Size(185, 63)
        Me.lblRank3.TabIndex = 31
        Me.lblRank3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblT3
        '
        Me.lblT3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblT3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblT3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblT3.Location = New System.Drawing.Point(1078, 368)
        Me.lblT3.Name = "lblT3"
        Me.lblT3.Size = New System.Drawing.Size(185, 63)
        Me.lblT3.TabIndex = 30
        Me.lblT3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblB3
        '
        Me.lblB3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblB3.Location = New System.Drawing.Point(52, 373)
        Me.lblB3.Name = "lblB3"
        Me.lblB3.Size = New System.Drawing.Size(182, 52)
        Me.lblB3.TabIndex = 29
        Me.lblB3.Text = "Boat #3"
        Me.lblB3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStatus
        '
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.Red
        Me.lblStatus.Location = New System.Drawing.Point(14, 659)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(247, 78)
        Me.lblStatus.TabIndex = 36
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1548, 734)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.txtB3R4)
        Me.Controls.Add(Me.txtB3R3)
        Me.Controls.Add(Me.txtB3R2)
        Me.Controls.Add(Me.txtB3R1)
        Me.Controls.Add(Me.lblRank3)
        Me.Controls.Add(Me.lblT3)
        Me.Controls.Add(Me.lblB3)
        Me.Controls.Add(Me.txtB2R4)
        Me.Controls.Add(Me.txtB2R3)
        Me.Controls.Add(Me.txtB2R2)
        Me.Controls.Add(Me.txtB2R1)
        Me.Controls.Add(Me.lblRank2)
        Me.Controls.Add(Me.lblT2)
        Me.Controls.Add(Me.lblB2)
        Me.Controls.Add(Me.txtB1R4)
        Me.Controls.Add(Me.txtB1R3)
        Me.Controls.Add(Me.txtB1R2)
        Me.Controls.Add(Me.txtB1R1)
        Me.Controls.Add(Me.lblRank1)
        Me.Controls.Add(Me.lblT1)
        Me.Controls.Add(Me.lblR1)
        Me.Controls.Add(Me.lblRank)
        Me.Controls.Add(Me.lblR2)
        Me.Controls.Add(Me.lblR3)
        Me.Controls.Add(Me.lblR4)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblB1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "Form1"
        Me.Text = "SailBoat Races with Rankings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblB1 As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblR4 As Label
    Friend WithEvents lblR3 As Label
    Friend WithEvents lblR2 As Label
    Friend WithEvents lblRank As Label
    Friend WithEvents lblR1 As Label
    Friend WithEvents lblT1 As Label
    Friend WithEvents lblRank1 As Label
    Friend WithEvents txtB1R1 As TextBox
    Friend WithEvents txtB1R2 As TextBox
    Friend WithEvents txtB1R3 As TextBox
    Friend WithEvents txtB1R4 As TextBox
    Friend WithEvents txtB2R4 As TextBox
    Friend WithEvents txtB2R3 As TextBox
    Friend WithEvents txtB2R2 As TextBox
    Friend WithEvents txtB2R1 As TextBox
    Friend WithEvents lblRank2 As Label
    Friend WithEvents lblT2 As Label
    Friend WithEvents lblB2 As Label
    Friend WithEvents txtB3R4 As TextBox
    Friend WithEvents txtB3R3 As TextBox
    Friend WithEvents txtB3R2 As TextBox
    Friend WithEvents txtB3R1 As TextBox
    Friend WithEvents lblRank3 As Label
    Friend WithEvents lblT3 As Label
    Friend WithEvents lblB3 As Label
    Friend WithEvents lblStatus As Label
End Class
