﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnMA = New System.Windows.Forms.Button()
        Me.btnNY = New System.Windows.Forms.Button()
        Me.BtnTX = New System.Windows.Forms.Button()
        Me.btnCA = New System.Windows.Forms.Button()
        Me.btnFL = New System.Windows.Forms.Button()
        Me.btnVA = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblMA = New System.Windows.Forms.Label()
        Me.lblNY = New System.Windows.Forms.Label()
        Me.lblTX = New System.Windows.Forms.Label()
        Me.lblCA = New System.Windows.Forms.Label()
        Me.lblFL = New System.Windows.Forms.Label()
        Me.lblVA = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(26, 95)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(279, 187)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnMA
        '
        Me.btnMA.Location = New System.Drawing.Point(433, 64)
        Me.btnMA.Name = "btnMA"
        Me.btnMA.Size = New System.Drawing.Size(207, 56)
        Me.btnMA.TabIndex = 1
        Me.btnMA.Text = "Massachussets"
        Me.btnMA.UseVisualStyleBackColor = True
        '
        'btnNY
        '
        Me.btnNY.Location = New System.Drawing.Point(433, 126)
        Me.btnNY.Name = "btnNY"
        Me.btnNY.Size = New System.Drawing.Size(207, 56)
        Me.btnNY.TabIndex = 2
        Me.btnNY.Text = "New York"
        Me.btnNY.UseVisualStyleBackColor = True
        '
        'BtnTX
        '
        Me.BtnTX.Location = New System.Drawing.Point(433, 188)
        Me.BtnTX.Name = "BtnTX"
        Me.BtnTX.Size = New System.Drawing.Size(207, 56)
        Me.BtnTX.TabIndex = 3
        Me.BtnTX.Text = "Texas"
        Me.BtnTX.UseVisualStyleBackColor = True
        '
        'btnCA
        '
        Me.btnCA.Location = New System.Drawing.Point(433, 250)
        Me.btnCA.Name = "btnCA"
        Me.btnCA.Size = New System.Drawing.Size(207, 56)
        Me.btnCA.TabIndex = 4
        Me.btnCA.Text = "California"
        Me.btnCA.UseVisualStyleBackColor = True
        '
        'btnFL
        '
        Me.btnFL.Location = New System.Drawing.Point(433, 312)
        Me.btnFL.Name = "btnFL"
        Me.btnFL.Size = New System.Drawing.Size(207, 56)
        Me.btnFL.TabIndex = 5
        Me.btnFL.Text = "Florida"
        Me.btnFL.UseVisualStyleBackColor = True
        '
        'btnVA
        '
        Me.btnVA.Location = New System.Drawing.Point(433, 374)
        Me.btnVA.Name = "btnVA"
        Me.btnVA.Size = New System.Drawing.Size(207, 56)
        Me.btnVA.TabIndex = 6
        Me.btnVA.Text = "Virginia"
        Me.btnVA.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(29, 542)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(266, 74)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(857, 542)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(266, 74)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblMA
        '
        Me.lblMA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblMA.Location = New System.Drawing.Point(769, 70)
        Me.lblMA.Name = "lblMA"
        Me.lblMA.Size = New System.Drawing.Size(66, 49)
        Me.lblMA.TabIndex = 9
        '
        'lblNY
        '
        Me.lblNY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNY.Location = New System.Drawing.Point(769, 133)
        Me.lblNY.Name = "lblNY"
        Me.lblNY.Size = New System.Drawing.Size(66, 49)
        Me.lblNY.TabIndex = 10
        '
        'lblTX
        '
        Me.lblTX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTX.Location = New System.Drawing.Point(769, 195)
        Me.lblTX.Name = "lblTX"
        Me.lblTX.Size = New System.Drawing.Size(66, 49)
        Me.lblTX.TabIndex = 11
        '
        'lblCA
        '
        Me.lblCA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCA.Location = New System.Drawing.Point(769, 257)
        Me.lblCA.Name = "lblCA"
        Me.lblCA.Size = New System.Drawing.Size(66, 49)
        Me.lblCA.TabIndex = 12
        '
        'lblFL
        '
        Me.lblFL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFL.Location = New System.Drawing.Point(769, 319)
        Me.lblFL.Name = "lblFL"
        Me.lblFL.Size = New System.Drawing.Size(66, 49)
        Me.lblFL.TabIndex = 13
        '
        'lblVA
        '
        Me.lblVA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblVA.Location = New System.Drawing.Point(769, 381)
        Me.lblVA.Name = "lblVA"
        Me.lblVA.Size = New System.Drawing.Size(66, 49)
        Me.lblVA.TabIndex = 14
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Cross
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox1.Location = New System.Drawing.Point(437, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(202, 30)
        Me.TextBox1.TabIndex = 15
        Me.TextBox1.Text = "STATE"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox2.Location = New System.Drawing.Point(769, 21)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(66, 28)
        Me.TextBox2.TabIndex = 16
        Me.TextBox2.Text = "AB"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1167, 629)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lblVA)
        Me.Controls.Add(Me.lblFL)
        Me.Controls.Add(Me.lblCA)
        Me.Controls.Add(Me.lblTX)
        Me.Controls.Add(Me.lblNY)
        Me.Controls.Add(Me.lblMA)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnVA)
        Me.Controls.Add(Me.btnFL)
        Me.Controls.Add(Me.btnCA)
        Me.Controls.Add(Me.BtnTX)
        Me.Controls.Add(Me.btnNY)
        Me.Controls.Add(Me.btnMA)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "Form1"
        Me.Text = "State Abbreviations"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnMA As Button
    Friend WithEvents btnNY As Button
    Friend WithEvents BtnTX As Button
    Friend WithEvents btnCA As Button
    Friend WithEvents btnFL As Button
    Friend WithEvents btnVA As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblMA As Label
    Friend WithEvents lblNY As Label
    Friend WithEvents lblTX As Label
    Friend WithEvents lblCA As Label
    Friend WithEvents lblFL As Label
    Friend WithEvents lblVA As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
End Class
