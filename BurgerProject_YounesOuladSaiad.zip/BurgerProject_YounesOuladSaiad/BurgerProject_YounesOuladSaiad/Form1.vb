﻿Public Class Form1
    ' Younes Oulad Saiad
    '14 December 2023
    'Final Project
    'This is a menu program that you can use to select the order Items and you get the total price 
    'I'm going to use in this program 
    '                            Select Case Statement 
    '                            If-Then Statement
    '                            MessageBox
    '                            InputBox
    '                            Do loop
    '                            Blinking Image
    '                            4 Variables and one constant.

    Private Sub btnTotal_Click(sender As Object, e As EventArgs) Handles btnTotal.Click

        'Declare Variables

        Dim dblSubtotal As Double 'first variable
        Dim dblTax As Double
        Dim dblTotal As Double

        Dim decBurger As Decimal '2nd variable
        Dim decToppings As Decimal
        Dim decBeverage As Decimal
        Dim intextrasprice As Integer '3rd variable
        Dim strextrasChoice As String  '4th variable


        ' Assign values
        ' Set prices for items


        Const Tax_Rate As Decimal = 0.0625 ' 6,25% Tax Rate


        Const PriceBeef As Decimal = 4.0 'constant
        Const PriceTurkey As Decimal = 4.25
        Const PriceVeggie As Decimal = 5.0
        Const PriceBuffalo As Decimal = 6.0

        Const PriceLettuce As Decimal = 0.1
        Const PriceTomato As Decimal = 0.1
        Const PriceOnion As Decimal = 0.1
        Const PricePickles As Decimal = 0.1
        Const PriceCheese As Decimal = 0.1
        Const PriceBacon As Decimal = 1.0
        Const PriceGaucamole As Decimal = 1.0
        Const PriceKetchup As Decimal = 0
        Const PriceMustard As Decimal = 0
        Const PriceMayo As Decimal = 0

        Const SizeSmall As Decimal = 1.5
        Const SizeMedium As Decimal = 2.0
        Const SizeLarge As Decimal = 2.5




        'Perform Calculation

        'Using If Statement 

        ' Handle Burger selection 

        If radBeef.Checked Then
            decBurger += PriceBeef
        End If
        If radTurkey.Checked Then
            decBurger += PriceTurkey
        End If
        If radVeggie.Checked Then
            decBurger += PriceVeggie
        End If
        If radBuffalo.Checked Then
            decBurger += PriceBuffalo

        End If


        ' Handle Toppings selection


        If chkLettuce.Checked Then
            decToppings += PriceLettuce
        End If

        If chkTomato.Checked Then
            decToppings += PriceTomato
        End If

        If chkOnion.Checked Then
            decToppings += PriceOnion
        End If

        If chkPickles.Checked Then
            decToppings += PricePickles
        End If

        If chkBacon.Checked Then
            decToppings += PriceBacon
        End If

        If chkCheese.Checked Then
            decToppings += PriceCheese
        End If

        If chkGaucamole.Checked Then
            decToppings += PriceGaucamole
        End If

        If chkKetchup.Checked Then
            decToppings += PriceKetchup
        End If

        If chkMustard.Checked Then
            decToppings += PriceMustard
        End If

        If chkMayo.Checked Then
            decToppings += PriceMayo

        End If

        ' Using Select Case

        ' Handle Beverage selection

        Select Case True

            Case radSmall.Checked
                decBeverage = SizeSmall

            Case radMedium.Checked

                decBeverage = SizeMedium

            Case radLarge.Checked

                decBeverage = SizeLarge


        End Select

        'Using InputBox
        'Using Do Loop for the inputBox until it says yes or no 
        Do

            strextrasChoice = InputBox("Would you like any extras? Yes or No", "Extra cost $1.00")
            If strextrasChoice.ToLower() = "yes" Then

                ' Set a price for extras
                intextrasprice = 1.0

            ElseIf strextrasChoice.ToLower() = "no" Then
                intextrasprice = 0

            Else
                ' Showing MessageBox
                MessageBox.Show("Yes or No ")

            End If
        Loop Until strextrasChoice.ToLower() = "yes" Or strextrasChoice.ToLower() = "no"

        ' Calculate subtotal
        dblSubtotal = decBurger + decToppings + decBeverage + intextrasprice
        ' Calculate Tax
        dblTax = dblSubtotal * Tax_Rate
        ' Calculate Total
        dblTotal = dblSubtotal + dblTax


        ' Display output
        lblSubtotal.Text = dblSubtotal.ToString("C")
        lblTax.Text = dblTax.ToString("C")
        lblTotal.Text = dblTotal.ToString("C")
        lblMsg.Text = ""





    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        ' Clear all the labels 

        lblSubtotal.Text = ""
        lblTax.Text = ""
        lblTotal.Text = ""

        ' Display message

        lblMsg.Text = "Thank you for choosing YNS's Fast Burger!"

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'Using MessageBox and Exit the Form by clicking Exit and ok 

        MessageBox.Show("See you later")
        Me.Close()

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Start the timer when the form loads
        Timer.Start()



    End Sub

    ' Timer control for blinking image
    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick
        ' Toggle visibility of the blinking image
        picBlinking.Visible = Not picBlinking.Visible
    End Sub




End Class
