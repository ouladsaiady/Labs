﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.txtW1 = New System.Windows.Forms.TextBox()
        Me.txtW4 = New System.Windows.Forms.TextBox()
        Me.txtW2 = New System.Windows.Forms.TextBox()
        Me.txtW3 = New System.Windows.Forms.TextBox()
        Me.txtW5 = New System.Windows.Forms.TextBox()
        Me.lblW1 = New System.Windows.Forms.Label()
        Me.lblW3 = New System.Windows.Forms.Label()
        Me.lblW4 = New System.Windows.Forms.Label()
        Me.lblW5 = New System.Windows.Forms.Label()
        Me.lblW2 = New System.Windows.Forms.Label()
        Me.lblAvg = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(46, 660)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(157, 56)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(356, 660)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(157, 56)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Red
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(727, 660)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(157, 56)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblResults
        '
        Me.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResults.Location = New System.Drawing.Point(439, 441)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(228, 59)
        Me.lblResults.TabIndex = 3
        Me.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtW1
        '
        Me.txtW1.Location = New System.Drawing.Point(439, 33)
        Me.txtW1.Multiline = True
        Me.txtW1.Name = "txtW1"
        Me.txtW1.Size = New System.Drawing.Size(235, 52)
        Me.txtW1.TabIndex = 4
        Me.txtW1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtW4
        '
        Me.txtW4.Location = New System.Drawing.Point(439, 246)
        Me.txtW4.Multiline = True
        Me.txtW4.Name = "txtW4"
        Me.txtW4.Size = New System.Drawing.Size(235, 52)
        Me.txtW4.TabIndex = 5
        Me.txtW4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtW2
        '
        Me.txtW2.Location = New System.Drawing.Point(439, 104)
        Me.txtW2.Multiline = True
        Me.txtW2.Name = "txtW2"
        Me.txtW2.Size = New System.Drawing.Size(235, 52)
        Me.txtW2.TabIndex = 6
        Me.txtW2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtW3
        '
        Me.txtW3.Location = New System.Drawing.Point(439, 174)
        Me.txtW3.Multiline = True
        Me.txtW3.Name = "txtW3"
        Me.txtW3.Size = New System.Drawing.Size(235, 52)
        Me.txtW3.TabIndex = 7
        Me.txtW3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtW5
        '
        Me.txtW5.Location = New System.Drawing.Point(439, 323)
        Me.txtW5.Multiline = True
        Me.txtW5.Name = "txtW5"
        Me.txtW5.Size = New System.Drawing.Size(235, 52)
        Me.txtW5.TabIndex = 8
        Me.txtW5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblW1
        '
        Me.lblW1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblW1.Location = New System.Drawing.Point(143, 33)
        Me.lblW1.Name = "lblW1"
        Me.lblW1.Size = New System.Drawing.Size(173, 52)
        Me.lblW1.TabIndex = 10
        Me.lblW1.Text = "Week #1: "
        Me.lblW1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblW3
        '
        Me.lblW3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblW3.Location = New System.Drawing.Point(143, 174)
        Me.lblW3.Name = "lblW3"
        Me.lblW3.Size = New System.Drawing.Size(173, 52)
        Me.lblW3.TabIndex = 11
        Me.lblW3.Text = "Week #3: "
        Me.lblW3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblW4
        '
        Me.lblW4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblW4.Location = New System.Drawing.Point(143, 246)
        Me.lblW4.Name = "lblW4"
        Me.lblW4.Size = New System.Drawing.Size(173, 52)
        Me.lblW4.TabIndex = 12
        Me.lblW4.Text = "Week #4: "
        Me.lblW4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblW5
        '
        Me.lblW5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblW5.Location = New System.Drawing.Point(143, 323)
        Me.lblW5.Name = "lblW5"
        Me.lblW5.Size = New System.Drawing.Size(173, 52)
        Me.lblW5.TabIndex = 13
        Me.lblW5.Text = "Week #5: "
        Me.lblW5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblW2
        '
        Me.lblW2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblW2.Location = New System.Drawing.Point(143, 104)
        Me.lblW2.Name = "lblW2"
        Me.lblW2.Size = New System.Drawing.Size(173, 52)
        Me.lblW2.TabIndex = 14
        Me.lblW2.Text = "Week #2: "
        Me.lblW2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAvg
        '
        Me.lblAvg.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvg.Location = New System.Drawing.Point(143, 441)
        Me.lblAvg.Name = "lblAvg"
        Me.lblAvg.Size = New System.Drawing.Size(173, 52)
        Me.lblAvg.TabIndex = 15
        Me.lblAvg.Text = "Average :"
        Me.lblAvg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(909, 728)
        Me.Controls.Add(Me.lblAvg)
        Me.Controls.Add(Me.lblW2)
        Me.Controls.Add(Me.lblW5)
        Me.Controls.Add(Me.lblW4)
        Me.Controls.Add(Me.lblW3)
        Me.Controls.Add(Me.lblW1)
        Me.Controls.Add(Me.txtW5)
        Me.Controls.Add(Me.txtW3)
        Me.Controls.Add(Me.txtW2)
        Me.Controls.Add(Me.txtW4)
        Me.Controls.Add(Me.txtW1)
        Me.Controls.Add(Me.lblResults)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "Form1"
        Me.Text = "Average"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblResults As Label
    Friend WithEvents txtW1 As TextBox
    Friend WithEvents txtW4 As TextBox
    Friend WithEvents txtW2 As TextBox
    Friend WithEvents txtW3 As TextBox
    Friend WithEvents txtW5 As TextBox
    Friend WithEvents lblW1 As Label
    Friend WithEvents lblW3 As Label
    Friend WithEvents lblW4 As Label
    Friend WithEvents lblW5 As Label
    Friend WithEvents lblW2 As Label
    Friend WithEvents lblAvg As Label
End Class
