﻿Public Class Form1
    'Younes Oulad Saiad
    '9-21-2023
    Private Sub btnMA_Click(sender As Object, e As EventArgs) Handles btnMA.Click
        lblMA.Text = "MA"
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblNY.Click

    End Sub

    Private Sub btnNY_Click(sender As Object, e As EventArgs) Handles btnNY.Click
        lblNY.Text = "NY"
    End Sub

    Private Sub BtnTX_Click(sender As Object, e As EventArgs) Handles BtnTX.Click
        lblTX.Text = "TX"
    End Sub

    Private Sub btnCA_Click(sender As Object, e As EventArgs) Handles btnCA.Click
        lblCA.Text = "CA"
    End Sub

    Private Sub btnFL_Click(sender As Object, e As EventArgs) Handles btnFL.Click
        lblFL.Text = "FL"
    End Sub

    Private Sub btnVA_Click(sender As Object, e As EventArgs) Handles btnVA.Click
        lblVA.Text = "VA"
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblMA.Text = ""
        lblNY.Text = ""
        lblTX.Text = ""
        lblCA.Text = ""
        lblFL.Text = ""
        lblVA.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class
