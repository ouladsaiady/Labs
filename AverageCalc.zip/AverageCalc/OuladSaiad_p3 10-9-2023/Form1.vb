﻿Public Class Form1
    ' Younes Oulad Saiad
    ' 10-9-2023

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        ' Declaring variables: 

        Dim dblW1 As Double
        Dim dblW2 As Double
        Dim dblW3 As Double
        Dim dblW4 As Double
        Dim dblW5 As Double
        Dim dblAverage As Double

        ' Assign Values from the User:
        Try
            dblW1 = txtW1.Text
            dblW2 = txtW2.Text
            dblW3 = txtW3.Text
            dblW4 = txtW4.Text
            dblW5 = txtW5.Text


            ' Perform Calculations:

            dblAverage = (dblW1 + dblW2 + dblW3 + dblW4 + dblW5) / 5

            ' Display Output:

            lblResults.Text = dblAverage
        Catch
            ' Error message
            MessageBox.Show("All input must be valid numeric values.")
        End Try


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblResults.Text = " "
        txtW1.Text = ""
        txtW2.Text = ""
        txtW3.Text = ""
        txtW4.Text = ""
        txtW5.Text = ""


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        MessageBox.Show("See you later")
        Me.Close()

    End Sub
End Class
