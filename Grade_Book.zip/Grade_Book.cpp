// Name: Younes Oulad Saiad
// Prof: Sylvia Yeung
// Summary: Exercise Grade Book
// the most difficult aspect is the results output 
// It took me about 2h to write this code
// 4-19-2024 start working on this assignment
// 4-21-2024 rev. and adding comments and organized the code

/*
Enter each student's name and their four test scores:
Enter the name of student 1: Younes
Enter test score 1 for Younes: 85.66
Enter test score 2 for Younes: 98
Enter test score 3 for Younes: 96   
Enter test score 4 for Younes: 92
Enter the name of student 2: Saiad 
Enter test score 1 for Saiad: 8085
Invalid input! Test score must be between 0 and 100. Please re-enter: 87
Enter test score 2 for Saiad: 83
Enter test score 3 for Saiad: 80
Enter test score 4 for Saiad: 87
Enter the name of student 3: Leo
Enter test score 1 for Leo: 40
Enter test score 2 for Leo: 74
Enter test score 3 for Leo: 38
Enter test score 4 for Leo: 50
Enter the name of student 4: Chris
Enter test score 1 for Chris: 60
Enter test score 2 for Chris: 64
Enter test score 3 for Chris: 68
Enter test score 4 for Chris: 62
Enter the name of student 5: Ronaldo
Enter test score 1 for Ronaldo: 79
Enter test score 2 for Ronaldo: 74
Enter test score 3 for Ronaldo: 78
Enter test score 4 for Ronaldo: 72

Results: 

Student   Dropped Score   Average Score   Letter Grade
-----------------------------------------------------------
    Younes          85.66          95.33              A
     Saiad          80.00          85.67              B
       Leo          38.00          54.67              F
     Chris          60.00          64.67              D
   Ronaldo          72.00          77.00              C
     */



#include <iostream> // Include the input/output stream library
#include <iomanip>  // Include the input/output manipulator library for formatting
#include <string>   // Include the string library

using namespace std; // Use the standard namespace

const int STUDENTS = 5;  // Number of students
const int SCORES = 4;     // Number of test scores per student

int main() {

    // Declare arrays to store student names, letter grades, average scores, and test scores

    string names[STUDENTS];            // Students' names
    char grades[STUDENTS];             // Students' letter grades
    double averages[STUDENTS];         // Students' average scores
    double testScores[STUDENTS][SCORES]; // Students' test scores

    // Prompt the user to input each student’s name and their four test scores

    cout << "Enter each student's name and their four test scores:" << endl;
    for (int i = 0; i < STUDENTS; i++) { // Loop through each student
        cout << "Enter the name of student " << i + 1<<": " ;
        cin >> names[i]; // Read student's name

        // Loop through each test score for the current student

        for (int j = 0; j < SCORES; j++) {
            // Prompt the user to input a test score
        cout << "Enter test score " << j + 1<< " for "<<names[i]<<": ";
            cin >> testScores[i][j]; // Read test score

            // Input validation: Reject test scores that are less than 0 or greater than 100

            while (testScores[i][j] < 0 || testScores[i][j] > 100) {
                cout << "Invalid input! Test score must be between 0 and 100. Please re-enter: ";
                cin >> testScores[i][j]; // Read test score again
            }
        }
    }

    // Calculate average test scores and assign letter grades for each student

    for (int i = 0; i < STUDENTS; i++) { // Loop through each student

        // Initialize variables for calculating average score and dropped score

        double sum = 0;
        double minScore = testScores[i][0]; // Initialize minScore to the first test score

        // Loop through each test score for the current student

        for (int j = 0; j < SCORES; j++) {
            sum += testScores[i][j]; // Add test score to sum

            // Update minScore if the current test score is lower

            if (testScores[i][j] < minScore) {
                minScore = testScores[i][j];
            }
        }

        // Calculate average test score (excluding the dropped score)

        averages[i] = (sum - minScore) / (SCORES - 1);

        // Assign letter grade based on the average score

        if (averages[i] >= 90) {
            grades[i] = 'A';
        } else if (averages[i] >= 80) {
            grades[i] = 'B';
        } else if (averages[i] >= 70) {
            grades[i] = 'C';
        } else if (averages[i] >= 60) {
            grades[i] = 'D';
        } else {
            grades[i] = 'F';
        }
    }

    // Display each student’s dropped score, average test score, and letter grade
    cout<<endl; //Print empty line
cout<< "Results: "<<endl;
  cout << "\nStudent\t  Dropped Score\t  Average Score\t  Letter Grade" << endl;
    cout << "-----------------------------------------------------------" << endl;
    for (int i = 0; i < STUDENTS; i++) {
        double minScore = testScores[i][0]; // Initialize minScore to the first test score

        // Find the minimum score
        for (int j = 0; j < SCORES; j++) {
            if (testScores[i][j] < minScore) {
                minScore = testScores[i][j];
            }
        }
        
        cout << setw(10)<< names[i] << setw(15) << minScore << setw(15) << setprecision(2) << fixed << averages[i]
             << setw(15) << grades[i] << endl; // Output student's name, dropped score, average score, and letter grade
    }
    return 0; // Return 0 to indicate successful execution
} // End of program
