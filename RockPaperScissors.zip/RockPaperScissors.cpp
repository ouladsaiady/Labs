// Name: Younes Oulad Saiad
// Prof: Sylvia Yeung
// Summary: Exercise Rock, Paper, Scissors Game
// the most difficult aspect is the random number
// It took me about 3h to write this code
// 4-18-2024 start working on this assignment
// 4-20-2024 rev. and adding comments and organized the code
 /*
Game Menu 
---------
1) Rock
2) Paper
3) Scissors
4) Quit

Enter your choice: 2
You Selected: Paper
Computer's choice: Paper
Tie. No winner.
Do you want to play again? (y/n): n
Thanks for playing Rock, Paper, Scissors!
*/



#include <iostream> // Include the input/output stream library
#include <cstdlib> // Include the standard library for functions like rand()
#include <ctime> // Include the time library for generating random seeds

using namespace std; // Use the standard namespace

// Function prototypes

int generateComputerChoice(); // Declare a function to generate the computer's choice
void displayMenu(); // Declare a function to display the menu
int getUserChoice(); // Declare a function to get the user's choice
void displayResult(int userChoice, int computerChoice); // Declare a function to display the result of the game

int main() {
    srand(time(0)); // Seed for random number generation

    char playAgain = 'y'; // Variable to track if the user wants to play again, initialized to 'y'

    // Main loop for the game

    while (playAgain == 'y' || playAgain == 'Y') { // Continue looping as long as user wants to play again
        int computerChoice = generateComputerChoice(); // Generate computer's choice

        // Display menu and get user's choice

        displayMenu();
        int userChoice = getUserChoice();
        
        // Exit loop if user chooses option 4

        if (userChoice == 4) {
            break; // Break out of the loop if user chooses to quit
        }

        // Display user's choice

        switch (userChoice) { // Check user's choice
            case 1:
                cout << "You Selected: Rock" << endl; // Display user's choice if it's Rock
                break;
            case 2:
                cout << "You Selected: Paper" << endl; // Display user's choice if it's Paper
                break;
            case 3:
                cout << "You Selected: Scissors" << endl; // Display user's choice if it's Scissors
                break;
        }       
          
        // Display computer's choice

        switch (computerChoice) { // Check computer's choice
            case 1:
                cout << "Computer's choice: Rock" << endl; // Display computer's choice if it's Rock
                break;
            case 2:
                cout << "Computer's choice: Paper" << endl; // Display computer's choice if it's Paper
                break;
            case 3:
                cout << "Computer's choice: Scissors" << endl; // Display computer's choice if it's Scissors
                break;
        }

        // Determine winner and display result

        displayResult(userChoice, computerChoice);

        // Ask user if they want to play again

        cout << "Do you want to play again? (y/n): ";
        cin >> playAgain;

        // Loop until valid input is received

        while (playAgain != 'y' && playAgain != 'Y' && playAgain != 'n' && playAgain != 'N') {
            cout << "Invalid input. Please enter 'y' or 'n': ";
            cin >> playAgain;
        }
    }

    cout << "Thanks for playing Rock, Paper, Scissors!" << endl; // Display a message when the game ends

    return 0; // Return 0 to indicate successful execution
}

// Function to generate computer's choice

int generateComputerChoice() { // Definition of function to generate computer's choice
    return rand() % 3 + 1; // Generates a random number between 1 and 3
}

// Function to display menu

void displayMenu() { // Definition of function to display menu
    cout << "Game Menu " << endl; // Display menu title
    cout<<"---------"<<endl; // Display menu separator
    cout << "1) Rock" << endl; // Display option 1
    cout << "2) Paper" << endl; // Display option 2
    cout << "3) Scissors" << endl; // Display option 3
    cout << "4) Quit" << endl; // Display option 4
}

// Function to get user's choice

int getUserChoice() { // Definition of function to get user's choice
    int choice; // Variable to store user's choice
    cout<<endl; // Print an empty line
    cout << "Enter your choice: "; // Prompt the user to enter their choice
    cin >> choice; // Get user's input

    while (choice < 1 || choice > 4) { // Validate user's input
        cout << "Invalid input. Please enter a number between 1 and 4: ";
        cin >> choice; // Get user's input again if it's invalid
    }
    return choice; // Return user's valid choice
}

// Function to display result

void displayResult(int userChoice, int computerChoice) { // Definition of function to display result

    // Determine the winner

    if (computerChoice == userChoice) { // If computer and user choose the same
        cout << "Tie. No winner." << endl; // Display tie message
    } else if ((computerChoice == 1 && userChoice == 3) || // Conditions for computer winning
               (computerChoice == 2 && userChoice == 1) ||
               (computerChoice == 3 && userChoice == 2)) {
        cout << "Computer wins! Paper wraps rock." << endl; // Display computer wins message
    } else { // If user wins
        cout << "You win! Rock smashes scissors." << endl; // Display user wins message
    }
}