// Name: Younes Oulad Saiad
// Prof: Sylvia Yeung
// Summary: Final Project
// the most difficult aspect is how to manage the various functionalities and ensuring they work seamlessly together.
// It took me about 6h to write this code
// 5-8-2024 start working on this assignment
// 5-12-2024 rev. and adding comments and organized the code

/*
***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 1

*** Seating Chart ***

Row  1: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  2: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  3: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  4: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  5: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  6: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  7: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  8: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  9: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 10: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 11: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 12: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 13: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 14: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 15: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 2

*** Seating Prices ***

Row  1: $30
Row  2: $30
Row  3: $30
Row  4: $30
Row  5: $20
Row  6: $20
Row  7: $20
Row  8: $20
Row  9: $12
Row 10: $12
Row 11: $12
Row 12: $12
Row 13: $8
Row 14: $8
Row 15: $8

***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 4

*** Request Tickets ***

Enter number of seats to purchase: 12
Enter row number for seat 1: 1
Enter seat number for seat 1: 6
Enter row number for seat 2: 2
Enter seat number for seat 2: 5
Enter row number for seat 3: 3
Enter seat number for seat 3: 4
Enter row number for seat 4: 4
Enter seat number for seat 4: 3
Enter row number for seat 5: 5
Enter seat number for seat 5: 2
Enter row number for seat 6: 6
Enter seat number for seat 6: 1
Enter row number for seat 7: 1
Enter seat number for seat 7: 1
Enter row number for seat 8: 2
Enter seat number for seat 8: 2
Enter row number for seat 9: 3
Enter seat number for seat 9: 3
Enter row number for seat 10: 4
Enter seat number for seat 10: 4
Enter row number for seat 11: 5
Enter seat number for seat 11: 5
Enter row number for seat 12: 6
Enter seat number for seat 12: 6
Tickets purchased successfully.
Subtotal: $320

***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 1

*** Seating Chart ***

Row  1: * # # # # * # # # # # # # # # # # # # # # # # # # # # # # # 
Row  2: # * # # * # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  3: # # * * # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  4: # # * * # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  5: # * # # * # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  6: * # # # # * # # # # # # # # # # # # # # # # # # # # # # # # 
Row  7: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  8: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row  9: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 10: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 11: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 12: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 13: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 14: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
Row 15: # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 5

*** Sales Report ***

Total Seats Sold: 12
Total Seats Available: 438
Total Sales: $320

***  C++ Theater  ***

1. Display the Seating Chart
2. Display Seating Prices
3. Update Seating Prices
4. Request Tickets
5. Print a Sales Report
6. Exit the Program

Enter your choice: 6
Exiting program.
*/
#include <iostream>
#include <iomanip>
#include <fstream> // For file operations

using namespace std;

//Constants

const int ROWS = 15;
const int SEATS_PER_ROW = 30;

// Function prototypes
void displayMenu();
void displaySeatingChart(bool seats[][SEATS_PER_ROW]);
void displaySeatingPrices(double seatPrices[]);
void updateSeatingPrices(double seatPrices[]);
void requestTickets(bool seats[][SEATS_PER_ROW], double seatPrices[], int& totalSold, double& totalSales);
void printSalesReport(int totalSold, double totalSales);
bool isValidSeat(int row, int seat);
bool isSeatAvailable(bool seats[][SEATS_PER_ROW], int row, int seat);
void markSeatTaken(bool seats[][SEATS_PER_ROW], int row, int seat);

int main() {

    // Initialize seating chart and prices
    bool seats[ROWS][SEATS_PER_ROW] = {false}; // 2D array to represent seat availability
    double seatPrices[ROWS] = {30.0, 30.0, 30.0, 30.0, 20.0, 20.0, 20.0, 20.0, 12.0, 12.0, 12.0, 12.0, 8.0, 8.0, 8.0}; // Array to store seat prices
    
    int totalSold = 0; // Variable to store total tickets sold
    double totalSales = 0.0; // Variable to store total sales
    
    int choice;
    do {
        displayMenu(); // Display the menu options
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                displaySeatingChart(seats); // Option to display seating chart
                break;
            case 2:
                displaySeatingPrices(seatPrices); // Option to display seating prices
                break;
            case 3:
                updateSeatingPrices(seatPrices); // Option to update seating prices
                break;
            case 4:
                requestTickets(seats, seatPrices, totalSold, totalSales); // Option to request tickets
                break;
            case 5:
                printSalesReport(totalSold, totalSales); // Option to print sales report
                break;
            case 6:
                cout<< endl; // Empty line
                cout << "Exiting program.\n"; // Option to exit the program
                cout<< endl; // Empty line
                cout<< "See you later!. \n ";
                break;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 6.\n"; // Handling invalid input
        }
    } while(choice != 6); // Continue loop until user chooses to exit

    return 0;
}

// Function to display the menu

void displayMenu() {
    cout << "\n***  C++ Theater  ***\n";
    cout << endl; // Empty line
    cout << "1. Display the Seating Chart\n";
    cout << "2. Display Seating Prices\n";
    cout << "3. Update Seating Prices\n";
    cout << "4. Request Tickets\n";
    cout << "5. Print a Sales Report\n";
    cout << "6. Exit the Program\n";
    cout<< endl; // Empty line
}

// Function to display the seating chart

void displaySeatingChart(bool seats[][SEATS_PER_ROW]) {
    cout << "\n*** Seating Chart ***\n";
    cout<< endl; // Empty line
    for (int i = 0; i < ROWS; ++i) {
        cout << "Row " << setw(2) << i+1 << ": ";
        for (int j = 0; j < SEATS_PER_ROW; ++j) {
            if (seats[i][j])
                cout << "* "; // '*' indicates seat is taken
            else
                cout << "# "; // '#' indicates seat is available
        }
        cout << endl;
    }
}

// Function to display seating prices

void displaySeatingPrices(double seatPrices[]) {
    cout << "\n*** Seating Prices ***\n";
    cout<< endl; // Empty line
    for (int i = 0; i < ROWS; ++i) {
        cout << "Row " << setw(2) << i+1 << ": $" << seatPrices[i] << endl;
    }
}

// Function to update seating prices

void updateSeatingPrices(double seatPrices[]) {
    cout << "\n*** Update Seating Prices ***\n";
    cout<< endl; // Empty line
    ofstream outFile("SeatPrices.txt"); // Open file for writing
    if (!outFile) {
        cerr << "Error opening file for writing." << endl;
        return;
    }
    
    for (int i = 0; i < ROWS; ++i) {
        cout << "Enter price for Row " << i+1 << ": $";
        cin >> seatPrices[i];

        outFile << i+1 << "    " << fixed << setprecision(2) << seatPrices[i] << endl; // Write row number and price to SeatPrices.txt
    }
    cout << "Seating prices updated successfully.\n";
    outFile.close(); // Close the file
}



// Function to request tickets

void requestTickets(bool seats[][SEATS_PER_ROW], double seatPrices[], int& totalSold, double& totalSales) {
    int numSeats, row, seat;
    double subtotal = 0.0;

    cout << "\n*** Request Tickets ***\n";
    cout<< endl; // Empty line
    cout << "Enter number of seats to purchase: ";
    cin >> numSeats;

    for (int i = 0; i < numSeats; ++i) {
        cout << "Enter row number for seat " << i+1 << ": ";
        cin >> row;
        cout << "Enter seat number for seat " << i+1 << ": ";
        cin >> seat;

        if (isValidSeat(row-1, seat-1) && isSeatAvailable(seats, row-1, seat-1)) {
            markSeatTaken(seats, row-1, seat-1);
            subtotal += seatPrices[row-1];
            totalSold++;
        } else {
            cout << "Invalid seat selection. Please try again.\n";
            --i; // Decrement i to re-prompt for this seat
        }
    }

    cout << "Tickets purchased successfully.\n";
    cout << "Subtotal: $" << subtotal << endl;
    totalSales += subtotal;
}

// Function to print sales report

void printSalesReport(int totalSold, double totalSales) {
    int totalSeats = ROWS * SEATS_PER_ROW;
    int availableSeats = totalSeats - totalSold;

    cout << "\n*** Sales Report ***\n";
    cout<< endl; // Empty line
    cout << "Total Seats Sold: " << totalSold << endl;
    cout << "Total Seats Available: " << availableSeats << endl;
    cout << "Total Sales: $" << totalSales << endl;
}

// Function to check if a seat is valid

bool isValidSeat(int row, int seat) {
    return row >= 0 && row < ROWS && seat >= 0 && seat < SEATS_PER_ROW;
}

// Function to check if a seat is available

bool isSeatAvailable(bool seats[][SEATS_PER_ROW], int row, int seat) {
    return !seats[row][seat]; // If seat is not taken, it's available
}

// Function to mark a seat as taken

void markSeatTaken(bool seats[][SEATS_PER_ROW], int row, int seat) {
    seats[row][seat] = true;
}
